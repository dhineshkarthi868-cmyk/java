package parking.model;
public interface Payable { long calculateFee(long minutes); }
