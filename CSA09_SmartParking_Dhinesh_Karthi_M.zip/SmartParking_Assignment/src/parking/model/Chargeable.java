package parking.model;
public interface Chargeable { int chargingSurchargePaise(); }
