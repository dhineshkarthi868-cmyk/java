# Task 7: Method Overriding and Object Contracts

TwoWheeler and Car override category() and hourlyRatePaise(). ElectricVehicle overrides category() and calculateFee(long), reusing super.calculateFee(minutes) and adding the charging surcharge. @Override requests compile-time verification that a method actually overrides a superclass or interface method. Vehicle overrides equals() and hashCode() so plates normalized to uppercase determine vehicle identity; if two vehicles are equal then their hash codes must agree. toString() gives a readable description. Plate-based equality is a design decision and assumes unique plate identifiers.

See `../src/` for the runnable implementation and `../tests/` for validation.
