# Task 5: Static Members and Object Life Cycle

Ticket.issued is a private static count incremented for each ticket; ParkingFacility.totalEntries is a private static counter of entries for the running JVM. Per-facility live occupancy is active.size(), not static, because independent facilities must not share active occupancy. Class initialization occurs when the JVM first actively uses a class; objects are constructed with new, remain reachable through maps and local references, and become eligible for garbage collection after all references disappear. Garbage collection timing is controlled by the JVM and cannot be guaranteed. These counters are demonstration-level; they reset at application restart and are not thread-safe. Production use would require storage and synchronization.

See `../src/` for the runnable implementation and `../tests/` for validation.
